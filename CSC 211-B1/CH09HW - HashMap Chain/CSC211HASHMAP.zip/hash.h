#ifndef HASH_H_
#define HASH_H_


/** Write a Hash Function Objects Template */


// Write a s`pecialization for string

// Write a specialization for int

#endif
