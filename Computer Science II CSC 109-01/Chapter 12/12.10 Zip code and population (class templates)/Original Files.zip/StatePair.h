/*
Author: Ben Carpenter
Copyright: 2024
*/

#ifndef STATEPAIR
#define STATEPAIR

template<typename T1, typename T2>
class StatePair {

// TODO: Define constructors
   StatePair();
   StatePair(T1 userKey, T2 userValue);
   
// TODO: Define mutators, and accessors for StatePair
	
// TODO: Define PrintInfo() method
};

#endif
