/*
Author: Ben Carpenter
Copyright: 2024
*/

#ifndef STR_INSTRUMENTH
#define STR_INSTRUMENTH

#include "Instrument.h"

class StringInstrument : public Instrument {
	// TODO: Declare private data members: numStrings, numFrets, 
	// isBowed // bool or int or string


	// TODO: Declare mutator functions - 
	//      SetNumOfStrings(), SetNumOfFrets(), SetIsBowed()


	// TODO: Declare accessor functions -
	//      GetNumOfStrings(), GetNumOfFrets(), GetIsBowed()


};

#endif
