#ifndef ESTR_INSTRUMENTH
#define ESTR_INSTRUMENTH

#include "StringInstrument.h"

class ElectricStrInstrument : public StringInstrument {
	// TODO: Declare private data members: current: 120/240 int or double or string
	
	

	// TODO: Declare mutator functions - 
	


	// TODO: Declare accessor functions -
	


};

#endif
