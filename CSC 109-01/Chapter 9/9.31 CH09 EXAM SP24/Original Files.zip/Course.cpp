#include <iostream>
#include "Course.h"
using namespace std;

// type your codee here