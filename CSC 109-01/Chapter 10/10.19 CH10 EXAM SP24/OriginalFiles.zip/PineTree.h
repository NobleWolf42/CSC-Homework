//
// Created by hloi on 4/5/2024.
//

/**
 * @file PineTree.h
 * @brief Represents a pine tree derived from the Tree base class.
 *
 * 2. **Derived Class Implementations**:
    - **`PineTree` Class**: Derives from `Tree`. Introduces a protected attribute `branchRings` 
    for the count of branch rings, correlating directly to the tree's age.
 * 
 * Implements age estimation specific to pine trees.
 */


    /**
     * Non default constructor
     * Constructs a PineTree object with specified species and location.
     * @param species Name of the pine tree species.
     * @param location Location of the pine tree.
     * @param branchRings The number of branch rings, indicating the age of the tree.
     */

    /** Override estimateAge method
    * Estimates the age of the Pine tree based on its branch rings.
    * @return The estimated age of the Pine tree.
    */
