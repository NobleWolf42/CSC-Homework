/**
 * @file Tree.h
 * @brief Abstract base class for representing a tree.
 *
 * Provides the interface for tree operations, including a method
 * to estimate the age of the tree, and is intended to be subclassed
 * by specific tree species implementations.

1. **Abstract Base Class `Tree` Implementation**:
    - Incorporate common attributes `species` and `location` as protected members to ensure they are 
    accessible to derived classes.
    - Construct a non default constructor
    - Define a pure virtual function `double estimateAge()` for age estimation, to be implemented by derived classes.
    - Implement a public method `displayInfo()` that prints the tree's species, location, and estimated age.

 */


        /** Non default constructor
         * Constructs a Tree object with given species and location.
         * @param species Name of the tree species.
         * @param location Location of the tree.
         */
        

        /** Virtual destructor. */
        

        /**double estimateAge();
         * Pure virtual method to estimate the age of the tree.
         * Must be implemented by derived classes.
         * @return Estimated age of the tree.
         * 
         */
        

        /** dislayInfo
         * void method
         * Displays information about the tree.
         * Displays the tree's species, age, and location.  Each field is separated by a space 
         * and end of line.
         */
        