//
// Created by hloi on 4/5/2024.
//
/**
 * @file RedOakTree.h
 * @brief Represents a Red OakTree tree, derived from the OakTree class.
 *
 * The RedOakTree class extends the OakTree class with specific behavior
 * for estimating the age of a Red Oak tree, which is based on the diameter X 1.5
 */
 
    /**
     * Constructs an OakTree object with specified location and attributes specific to oak trees.
     * @param species The species of the red oak tree.
     * @param location The geographical location of the red oak tree.
     * @param diameter The diameter of the red oak tree.
     */
    
    /**
     * Estimates the age of the red oak tree based on oak-specific criteria.
     * @return The estimated age of the oak tree.
     * age = diameter x 1.5.
     */
    

};

#endif // REDOAKTREE_H

