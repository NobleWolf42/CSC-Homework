#include "PineTree.h"
#include "WhitePineTree.h"
#include "OakTree.h"
#include "RedOakTree.h"
#include "Tree.h"
#include <iostream>

int main() {
    OakTree myOakTree("Oak", "Oakwood Park", 10.5);
    PineTree myPineTree("Pine", "Pinecrest Forest", 75);

    // std::cout << "Oak Tree Info:" << std::endl;
    myOakTree.dislayInfo();
    // std::cout << "Estimated Age: " << myOakTree.estimateAge() << " years" << std::endl;

    // std::cout << "Pine Tree Info:" << std::endl;
    myPineTree.dislayInfo();
    // std::cout << "Estimated Age: " << myPineTree.estimateAge() << " years" << std::endl;

    WhitePineTree whitePine("White Pine", "Northern Forest", 50);
    RedOakTree redOak("Red Oak", "Deciduous Forest", 20);

    whitePine.dislayInfo();
    // std::cout << "Estimated Age: " << whitePine.estimateAge() << " years" << std::endl;

    redOak.dislayInfo();
    // std::cout << "Estimated Age: " << redOak.estimateAge() << " years" << std::endl;


    return 0;
}
